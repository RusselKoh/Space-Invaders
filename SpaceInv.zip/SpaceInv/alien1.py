import pygame
from alien import Alien


class Alien1(Alien):
    def __init__(self, ai_settings, screen):
        super(Alien1, self).__init__(ai_settings, screen)
        self.ai_settings = ai_settings

        # Load the alien image and set its rect attribute.
        self.image = pygame.transform.scale((pygame.image.load('images/enemy1_2.png')), (60, 60))

    def give_points(self):
        return self.ai_settings.alien1_points
