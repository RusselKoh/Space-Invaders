import pygame.ftfont


class Button:
    def __init__(self, screen, msg):
        self.screen = screen
        self.screen_rect = screen.get_rect()

        # Set dimensions and props of the button
        self.width, self.height = 200, 50
        self.button_color = (0, 255, 0)
        self.text_color = (255, 255, 255)
        self.font = pygame.font.SysFont(None, 48)
        self.msg_image = self.font.render(msg, True, self.text_color, self.button_color)
        self.msg_image_rect = self.msg_image.get_rect()

        # Build the button's rect object and center it.
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.center = (600, 600)

        # The button message needs to be prepped only once.
        self.prep_msg()

    def prep_msg(self):
        self.msg_image_rect.center = (600, 600)
        self.rect.center = (600, 600)

    def prep_location(self, width, height):
        self.msg_image_rect.center = (width, height)
        self.rect.center = (width, height)

    def draw_button(self):
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.msg_image, self.msg_image_rect)


class Highscore(Button):
    def __init__(self, screen, msg):
        super(Highscore, self).__init__(screen, msg)
        self.rect.center = (600, 700)

    def prep_msg(self):
        self.msg_image_rect.center = (600, 700)

    def draw_highscore(self):
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.msg_image, self.msg_image_rect)


class Title(Button):
    def __init__(self, screen, msg):
        super(Title, self).__init__(screen, msg)

    def prep_msg(self):
        self.msg_image_rect.center = (600, 100)

    def draw_title(self):
        self.screen.blit(self.msg_image, self.msg_image_rect)


class PointText(Button):
    def __init__(self, screen, msg):
        super(PointText, self).__init__(screen, msg)
        self.msg_image = self.font.render("= " + msg + " Points", True, self.text_color, self.button_color)

    def draw_point(self):
        self.screen.blit(self.msg_image, self.msg_image_rect)


class PlainText(Button):
    def __init__(self, screen, msg):
        super(PlainText, self).__init__(screen, msg)
        self.msg_image = self.font.render(msg, True, self.text_color, self.button_color)

    def draw_plain_text(self):
        self.screen.blit(self.msg_image, self.msg_image_rect)


class HighscoreText(Button):
    def __init__(self, screen, msg):
        super(HighscoreText, self).__init__(screen, msg)
        self.msg_image = self.font.render(msg, True, self.text_color, self.button_color)
        self.width, self.height = 50, 50
        self.rect = pygame.Rect(0, 0, self.width, self.height)

    def prep_location(self, width, height):
        self.msg_image_rect.center = (width, height)

    def draw_button(self):
        self.screen.blit(self.msg_image, self.msg_image_rect)
