import pygame
from alien import Alien


class Alien3(Alien):
    def __init__(self, ai_settings, screen):
        super(Alien3, self).__init__(ai_settings, screen)
        self.ai_settings = ai_settings

        # Load the alien image and set its rect attribute.
        self.image = pygame.transform.scale((pygame.image.load('images/enemy3_1')), (60, 60))

    def give_points(self):
        return self.ai_settings.alien3_points
