import pygame
from button import HighscoreText


class HomeScreen:
    def __init__(self, screen, stats):
        self.bg_color = (0, 0, 0)
        self.screen = screen
        self.stats = stats
        self.screen_rect = screen.get_rect()
        self.alien1 = pygame.transform.scale((pygame.image.load('images/enemy1_1.png')), (60, 60))
        self.alien2 = pygame.transform.scale((pygame.image.load('images/enemy2_1.png')), (60, 60))
        self.alien3 = pygame.transform.scale((pygame.image.load('images/enemy3_1.png')), (60, 60))

    def screen_fill(self):
        self.screen.fill(self.bg_color)
        self.screen.blit(self.alien1, (400, 200))
        self.screen.blit(self.alien2, (400, 300))
        self.screen.blit(self.alien3, (400, 400))

    def highscore_screen(self, screen):
        self.screen.fill(self.bg_color)
        f = open("highscore/highscore.txt", "r")
        file = f.readlines()

        for i in range(10):
            highscore_text = HighscoreText(screen, (str(i + 1) + ") " + file[i]))
            highscore_text.prep_location(600, (100 + i * 50))
            highscore_text.draw_button()
